---------------------------------------------------------------
         Connect Construct 2 to Facebook and Firebase
    Created by : Agit Tri Mulyanto (http://agittm.itch.io)
---------------------------------------------------------------
                    | ver : 1.2 |
                    -------------

Hi, thanks for download this template.
Don't forget to follow me on itch.io.

-----------------------------------------------------------

About License :

You can use this template in unlimited number of commercial
or non-commercial project. But limited to 1 person or a team.

Please do not copy, share, or re-sell this template!
-----------------------------------------------------------

===========
Instruction
===========

This template uses the following plugin :
- rex_firebase_api
- rex_firebase_apiV3
- rex_firebase_authentication

Install it under [YOUR_CONSTRUCT2_FOLDER]/exporters/html5/plugins

After that, follow the tutorial provided in the zip.

------------------------------------------------------
Changelog :

1.2 :
- Removed some unused FB permission
1.1 :
-Added TextBox for showing log
1.0 :
-General release
-----------------------------------------------------